
package com.muleinaction;

public abstract class Constants
{
    public static String MESSAGE_XML_V1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><fake/>";
    public static String MESSAGE_XML_V2 = MESSAGE_XML_V1;
    public static final String ACME_TEST_MESSAGE = "\"test_message\"";
}
