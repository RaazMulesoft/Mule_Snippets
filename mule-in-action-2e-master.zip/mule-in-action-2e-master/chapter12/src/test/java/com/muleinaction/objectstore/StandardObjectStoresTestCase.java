
package com.muleinaction.objectstore;

public class StandardObjectStoresTestCase extends AbstractObjectStoreTestCase
{
    @Override
    protected String getConfigResources()
    {
        return "standard-object-stores-config.xml";
    }
}
