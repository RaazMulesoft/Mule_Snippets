
package com.muleinaction.pattern.validator;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.mule.api.MuleMessage;
import org.mule.module.client.MuleClient;
import org.mule.tck.junit4.FunctionalTestCase;

public class PatternValidatorInheritanceTestCase extends FunctionalTestCase
{

    @Override
    protected String getConfigResources()
    {
        return "pattern/validator/pattern-validator-inheritance.xml";
    }

    
    @Test
    public void testIntegerValidator() throws Exception
    {
        MuleClient muleClient = new MuleClient(muleContext);

        int payload = 0;

        MuleMessage result = muleClient.send("vm://integer-service.in", payload, null);
        MuleMessage outboundResult = muleClient.request("vm://real-integer-service.in", 2000);

        assertThat(result.getPayloadAsString(), equalTo("Message accepted."));
        assertThat((Integer) outboundResult.getPayload(), equalTo(payload));
    }
    
    @Test
    public void testIntegerValidatorInvalid() throws Exception
    {
        MuleClient muleClient = new MuleClient(muleContext);

        String payload = "Hello World";

        MuleMessage result = muleClient.send("vm://integer-service.in", payload, null);

        assertThat(result.getPayloadAsString(), equalTo("Message rejected."));
    }
    
    @Test
    public void testStringValidator() throws Exception
    {
        MuleClient muleClient = new MuleClient(muleContext);

        String payload = "Hello World";

        MuleMessage result = muleClient.send("vm://string-service.in", payload, null);
        MuleMessage outboundResult = muleClient.request("vm://real-string-service.in", 2000);

        assertThat(result.getPayloadAsString(), equalTo("Message accepted."));
        assertThat(outboundResult.getPayloadAsString(), equalTo(payload));
    }
    
    @Test
    public void testStringValidatorInvalid() throws Exception
    {
        MuleClient muleClient = new MuleClient(muleContext);

        int payload = 0;
        
        MuleMessage result = muleClient.send("vm://string-service.in", payload, null);

        assertThat(result.getPayloadAsString(), equalTo("Message rejected."));
    }

}
