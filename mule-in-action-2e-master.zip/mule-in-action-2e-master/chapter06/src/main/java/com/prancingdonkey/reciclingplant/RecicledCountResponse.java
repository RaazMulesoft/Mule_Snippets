package com.prancingdonkey.reciclingplant;


public class RecicledCountResponse {
	
	int count;

	public int getType() {
		return count;
	}

	public void setType(int count) {
		this.count = count;
	}
	 
}
