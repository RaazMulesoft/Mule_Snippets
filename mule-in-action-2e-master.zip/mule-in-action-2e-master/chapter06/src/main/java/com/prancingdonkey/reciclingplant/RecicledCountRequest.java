package com.prancingdonkey.reciclingplant;


public class RecicledCountRequest {
	
	String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	 
}
