package org.mule.modules;

public class WeatherException extends Exception {
}
