package org.external.model;

public class Weather {

}
