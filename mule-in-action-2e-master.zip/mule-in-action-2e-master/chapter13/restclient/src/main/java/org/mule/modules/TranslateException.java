package org.mule.modules;

public class TranslateException extends RuntimeException {

	public TranslateException(){
	}
	
	public TranslateException(String reason){
	}
}
