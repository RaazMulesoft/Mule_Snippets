package com.prancingdonkey.service;

import com.prancingdonkey.domain.Order;

public class OrderPreProcessingService {


    public Order order(String brewXml) {
        return new Order();
    }

}
