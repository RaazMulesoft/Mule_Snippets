package com.prancingdonkey.service;

import com.prancingdonkey.domain.Order;

public class OrderProcessingService {

    public void process(Order order) {
    }

}
