package com.prancingdonkey.domain;

import java.io.Serializable;

public class Brew implements Serializable {

}
