package com.prancingdonkey.service;


public class LowPriorityOrderProcessingService {

    public void process(String orderXml) {
    }
}
