package com.prancingdonkey.service;

import com.prancingdonkey.domain.Order;

public class HighPriorityOrderProcessingService {


    public void process(String orderXml) {

    }

    public void process(Order order) {

    }

}
