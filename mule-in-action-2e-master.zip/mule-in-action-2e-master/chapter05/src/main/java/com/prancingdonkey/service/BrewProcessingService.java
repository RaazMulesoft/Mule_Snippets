package com.prancingdonkey.service;

import com.prancingdonkey.domain.Brew;

public class BrewProcessingService {

    public void process(Brew brew) {
        //NOOP
    }

}
