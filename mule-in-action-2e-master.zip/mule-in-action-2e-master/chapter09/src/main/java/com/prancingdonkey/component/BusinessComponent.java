package com.prancingdonkey.component;


/**
 * Mock Component
 */
public class BusinessComponent {
	
	public Object process(Object object) throws Exception {
        return "";
    }
    
}
