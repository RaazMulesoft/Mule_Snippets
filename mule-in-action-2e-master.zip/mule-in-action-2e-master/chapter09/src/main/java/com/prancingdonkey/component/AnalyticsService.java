package com.prancingdonkey.component;


/**
 * Mock Component
 */
public class AnalyticsService {
	
	public Object process(Object object) throws Exception {
        return "";
    }
    
}
