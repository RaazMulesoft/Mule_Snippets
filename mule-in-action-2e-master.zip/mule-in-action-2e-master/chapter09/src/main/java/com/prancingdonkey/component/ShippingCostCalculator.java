package com.prancingdonkey.component;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class ShippingCostCalculator implements Callable {
	
	public Object onCall(MuleEventContext eventContext)
			throws Exception {
		throw new java.lang.IllegalStateException();
	}
}

