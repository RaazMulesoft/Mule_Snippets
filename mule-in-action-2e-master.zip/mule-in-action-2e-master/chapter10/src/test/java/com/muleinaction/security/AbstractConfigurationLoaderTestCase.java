
package com.muleinaction.security;

import org.junit.Test;
import org.mule.tck.junit4.FunctionalTestCase;

public abstract class AbstractConfigurationLoaderTestCase extends FunctionalTestCase
{
    @Test
    public void ensureConfigLoads() throws Exception
    {
        // NOOP
    }
}
