package com.prancingdonkey.service;

import com.prancingdonkey.model.Report;

public class FraudDetectionService {

    public Report process(Report report) {
        return report;
    }
}
