package com.prancingdonkey.service;

import com.prancingdonkey.model.Report;


public class DataWarehousingService {

    public Report process(Report report) {
        return report;
    }
}
