package com.prancingdonkey.service;


import com.prancingdonkey.model.Report;

public class DataPeristenceService {


    public Report process(Report report) {
        return report;
    }

}
