
package org.external;

public class ExternalItem
{

    String itemNumber;

    String unwantedValue;

    public String getItemNumber()
    {
        return itemNumber;
    }

    public void setItemNumber(String itemNumber)
    {
        this.itemNumber = itemNumber;
    }

    public String getUnwantedValue()
    {
        return unwantedValue;
    }

    public void setUnwantedValue(String unwantedValue)
    {
        this.unwantedValue = unwantedValue;
    }

}
