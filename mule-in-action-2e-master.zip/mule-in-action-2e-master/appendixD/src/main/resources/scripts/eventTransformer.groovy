import com.prancingdonkey.product.event.ProductIngestCompleted

return new ProductIngestCompleted(date: new Date(), count: message);