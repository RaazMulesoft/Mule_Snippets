
package com.prancingdonkey.resource;

import javax.ws.rs.Path;

@Path("/accounts")
public class Accounts
{
    // STUB
}
