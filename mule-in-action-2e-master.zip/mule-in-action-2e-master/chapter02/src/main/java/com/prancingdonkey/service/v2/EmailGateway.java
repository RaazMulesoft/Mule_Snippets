
package com.prancingdonkey.service.v2;


public class EmailGateway
{
    // STUB
}
