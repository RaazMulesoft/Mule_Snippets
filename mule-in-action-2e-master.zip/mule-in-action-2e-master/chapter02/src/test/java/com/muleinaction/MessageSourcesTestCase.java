
package com.muleinaction;

public class MessageSourcesTestCase extends AbstractConfigurationLoaderTestCase
{
    @Override
    protected String getConfigResources()
    {
        return "message-sources.xml";
    }
}
