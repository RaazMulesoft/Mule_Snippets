
package com.muleinaction;

public class MessageExchangePatternsTestCase extends AbstractConfigurationLoaderTestCase
{
    @Override
    protected String getConfigResources()
    {
        return "message-exhange-patterns.xml";
    }
}
