
package com.muleinaction;

public class EndpointUrisTestCase extends AbstractConfigurationLoaderTestCase
{
    @Override
    protected String getConfigResources()
    {
        return "endpoint-uris.xml";
    }
}
